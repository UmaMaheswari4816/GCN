import pandas as pd
import networkx as nx
import matplotlib.pyplot as plt
import ast
import numpy as np
import math
import torch
import os



class LoadGraph:
    def __init__(self, df, discussionId):
        self.df = df
        self.discussionId = discussionId
        self.labels = eval(self.df.loc[self.df['discussion_id'] == self.discussionId, 'discussion_stance_id'].values[0])
        self.author_ids = eval(self.df.loc[self.df['discussion_id'] == self.discussionId, 'author_id'].values[0])
        self.post_ids = eval(self.df.loc[self.df['discussion_id'] == self.discussionId, 'post_id'].values[0])
        self.p_pids = self.df.loc[self.df['discussion_id'] == self.discussionId, 'parent_post_id'].values[0]
        # print("p_pids :",self.p_pids)
        self.parent_post_ids = []
        self.G_author = []
        self.G_post = []
        self.adjMatrix = None
        self.idx_train = torch.Tensor()
        self.idx_val = torch.Tensor()
        self.idx_test = torch.Tensor()
        print(self.author_ids)

    # Replacing the Nan values with None
    def loaddata(self):
        self.p_pids = [np.nan if x == 'nan' else float(x) for x in self.p_pids.strip('[]').split(',')]
        for i in range(len(self.p_pids)):
            if not math.isnan(self.p_pids[i]):
                self.parent_post_ids.append(int(self.p_pids[i]))
            else:
                self.parent_post_ids.append(None)
        print('author_ids:', self.author_ids)
        print('stance:', self.labels)
        print('post_ids:', self.post_ids)
        print('parent_post_ids:', self.parent_post_ids)

    # Construction of post id graph

    def postid_DrawGraph(self):
        # Data
        inital_post_id = str(self.df.loc[self.df['discussion_id'] == self.discussionId, 'initiating_author_id'].values[0]) + str(
            self.df.loc[self.df['discussion_id'] == self.discussionId, 'title'].values[0])
        print(str(self.df.loc[self.df['discussion_id'] == self.discussionId, 'title'].values[0]))
        # Create an empty directed graph
        self.G_post = nx.Graph()

        # Add initiating_author_id node
        self.G_post.add_node(inital_post_id)

        # Add post_id nodes
        for pid in self.post_ids:
            self.G_post.add_node(pid)

        # Connect author_ids to initiating_author_id or parent_post_ids
        for i, parent_post_id in enumerate(self.parent_post_ids):
            if parent_post_id is None:
                self.G_post.add_edge(inital_post_id, self.post_ids[i])
            else:
                self.G_post.add_edge(parent_post_id, self.post_ids[i])

        # Draw the graph
        plt.figure(figsize=(10, 8))  # Set the size of the figure
        pos = nx.spring_layout(self.G_post)  # Calculate the layout of the graph
        nx.draw(self.G_post, pos, with_labels=True, node_color='lightblue', node_size=1000, edge_color='gray',
                arrows=True)

        plt.show()
        plt.savefig('graph.png', format='png')


    # converting all parameters into tensor file(.pt)

    def totensor_G_post(self):
        labels_len = len(self.labels)
        self.labels = torch.tensor(self.labels)
        # print("postids:",len(self.post_ids))
        adj_matrix = nx.adjacency_matrix(self.G_post).todense()

        adj_matrix = adj_matrix[:labels_len, :labels_len]

        self.adjMatrix = torch.tensor(adj_matrix)
        self.adjMatrix = self.adjMatrix.to_sparse().to(torch.float)
        number = labels_len
        a = int(number * 0.5)
        b = int(number * 0.2)
        c = int(number * 0.3)
        print(a,b,c)
        # print(type(a),b,c)
        idx_train = range(a)
        idx_vali = range(a, a+b)
        idx_test = range(a+b, number)
        idx_train = [x for x in idx_train]
        list_vali = [x for x in idx_vali]
        list_test = [x for x in idx_test]

        self.idx_train = torch.tensor(idx_train)
        self.idx_val = torch.tensor(list_vali)
        self.idx_test = torch.tensor(idx_test)

        print(self.adjMatrix.shape)
        # print(features.shape)
        print(self.labels.shape)
        print(self.idx_train.shape)
        print(self.idx_val.shape)
        print(self.idx_test.shape)

    # Save the .pt files into the tensorFiles directory

    def savePt(self):
        path = 'TensorFiles/discussion_'+str(self.df.loc[self.df['discussion_id'] == self.discussionId, 'discussion_id'].values[0])
        # print(self.df['discussion_id'][39])
        if not os.path.exists(path):
            os.mkdir(path)

        torch.save(self.adjMatrix, path + '/adj.pt')
        torch.save(self.labels, path + '/labels.pt')
        # torch.save(features, path+'/features.pt')
        torch.save(self.idx_train, path + '/idx_train.pt')
        torch.save(self.idx_val, path + '/idx_val.pt')
        torch.save(self.idx_test, path + '/idx_test.pt')
