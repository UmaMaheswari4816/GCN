from __future__ import division
from __future__ import print_function
import time
import numpy as np
import torch
import torch.nn.functional as F
import torch.optim as optim
import pandas as pd
import scipy.sparse as sp
import math
from torch.nn.parameter import Parameter
from torch.nn.modules.module import Module
import torch.nn as nn


class GraphConvolution(Module):
    def __init__(self, in_features, out_features, bias=True):
        super(GraphConvolution, self).__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.weight = Parameter(torch.FloatTensor(in_features, out_features))
        if bias:
            self.bias = Parameter(torch.FloatTensor(out_features))
        else:
            self.register_parameter('bias', None)
        self.reset_parameters()

    def reset_parameters(self):
        stdv = 1. / math.sqrt(self.weight.size(1))
        self.weight.data.uniform_(-stdv, stdv)
        if self.bias is not None:
            self.bias.data.uniform_(-stdv, stdv)

    def forward(self, input, adj):
        support = torch.mm(input, self.weight)
        output = torch.spmm(adj, support)
        if self.bias is not None:
            return output + self.bias
        else:
            return output

    def __repr__(self):
        return self.__class__.__name__ + ' (' \
               + str(self.in_features) + ' -> ' \
               + str(self.out_features) + ')'


class GCN(nn.Module):
    def __init__(self, nfeat, nhid, nclass, dropout):
        super(GCN, self).__init__()

        self.gc1 = GraphConvolution(nfeat, nhid)
        self.gc2 = GraphConvolution(nhid, nclass)
        self.dropout = dropout

    def forward(self, x, adj):
        x = F.relu(self.gc1(x, adj))
        x = F.dropout(x, self.dropout, training=self.training)
        x = self.gc2(x, adj)
        return F.log_softmax(x, dim=1)

#
# def train(features, adj, labels, idx_train, idx_val, model, optimizer, num_epoch, print_every=20, fastmode=False):
#     t_total = time.time()
#
#     for epoch in range(num_epoch):
#         t = time.time()
#         model.train()
#         optimizer.zero_grad()
#         output = model(features, adj)
#         acc_train = accuracy(output[idx_train], labels[idx_train])
#         loss_train = F.nll_loss(output[idx_train], labels[idx_train])
#         loss_train.backward()
#         optimizer.step()
#
#         if epoch % print_every == 0:
#             if not fastmode:
#                 # Evaluate validation set performance separately,
#                 # deactivates dropout during validation run.
#                 model.eval()
#                 output = model(features, adj)
#
#             loss_val = F.nll_loss(output[idx_val], labels[idx_val])
#             acc_val = accuracy(output[idx_val], labels[idx_val])
#             print('Epoch: {:04d}'.format(epoch + 1),
#                   'loss_train: {:.4f}'.format(loss_train.item()),
#                   'acc_train: {:.4f}'.format(acc_train.item()),
#                   'loss_val: {:.4f}'.format(loss_val.item()),
#                   'acc_val: {:.4f}'.format(acc_val.item()),
#                   'time: {:.4f}s'.format(time.time() - t))
#
#     print("Optimization Finished!")
#     print("Total time elapsed: {:.4f}s".format(time.time() - t_total))
# def test(features, adj, labels, idx_test, model):
#     model.eval()
#     output = model(features, adj)
#     loss_test = F.nll_loss(output[idx_test], labels[idx_test])
#     acc_test = accuracy(output[idx_test], labels[idx_test])
#     print("Test set results:",
#           "loss= {:.4f}".format(loss_test.item()),
#           "accuracy= {:.4f}".format(acc_test.item()))
#
#     # Convert the predicted outputs to class labels
#     _, predicted_labels = output.max(dim=1)
#
#     # Get the true labels
#     true_labels = labels[idx_test]
#
#     # Compare predicted and true labels
#     num_samples = len(idx_test)
#     c=0
#     for i in range(num_samples):
#         # print("Sample {}: Predicted label = {}, True label = {}".format(i + 1, predicted_labels[idx_test[i]].item(),
#         #                                                                 true_labels[i].item()))
#         if predicted_labels[idx_test[i]].item() !=  true_labels[i].item():
#             c+=1
#
#     print("wrong predictions c
#
#
# #BCE

def train(features, adj, labels, idx_train, idx_val, model, optimizer, num_epoch, print_every=50, fastmode=False):
    t_total = time.time()

    for epoch in range(num_epoch):
        t = time.time()
        model.train()
        optimizer.zero_grad()
        output = model(features, adj)

        # Convert the labels to long tensor if they are not already
        labels = labels.long()

        # Select the relevant output and labels for training
        output_train = output[idx_train]
        labels_train = labels[idx_train]

        # Calculate the binary cross-entropy loss
        loss_train = F.cross_entropy(output_train, labels_train)
        acc_train = accuracy(output_train, labels_train)

        loss_train.backward()
        optimizer.step()

        if epoch % print_every == 0:
            if not fastmode:
                # Evaluate validation set performance separately,
                # deactivates dropout during validation run.
                model.eval()
                output_val = model(features, adj)
                # Select the relevant output and labels for validation
                output_val = output_val[idx_val]
                labels_val = labels[idx_val]

            loss_val = F.cross_entropy(output_val, labels_val)
            acc_val = accuracy(output_val, labels_val)

            print('Epoch: {:04d}'.format(epoch + 1),
                  'loss_train: {:.4f}'.format(loss_train.item()),
                  'acc_train: {:.4f}'.format(acc_train.item()),
                  'loss_val: {:.4f}'.format(loss_val.item()),
                  'acc_val: {:.4f}'.format(acc_val.item()),
                  'time: {:.4f}s'.format(time.time() - t))

    print("Optimization Finished!")
    print("Total time elapsed: {:.4f}s".format(time.time() - t_total))


def test(features, adj, labels, idx_test, model):
    model.eval()
    output = model(features, adj)

    # Select the relevant output and labels for testing
    output_test = output[idx_test]
    labels_test = labels[idx_test]

    # Apply sigmoid function to the output tensor
    output_test = torch.sigmoid(output_test)

    # Convert the labels to float
    labels_float = labels_test.float()

    # Calculate the binary cross-entropy loss
    loss_test = F.binary_cross_entropy(output_test[:, 1], labels_float)

    # Calculate accuracy assuming binary classification (optional)
    predicted_labels = torch.round(output_test[:, 1])  # Round predictions to 0 or 1
    correct_predictions = torch.eq(predicted_labels, labels_test).sum().item()
    acc_test = correct_predictions / len(idx_test)

    print("Test set results:",
          "loss= {:.4f}".format(loss_test.item()),
          "accuracy= {:.4f}".format(acc_test))
    return output, loss_test


def test(features, adj, labels, idx_test, model):
    model.eval()
    output = model(features, adj)
    loss_test = F.nll_loss(output[idx_test], labels[idx_test])
    acc_test = accuracy(output[idx_test], labels[idx_test])
    print("Test set results:",
          "loss= {:.4f}".format(loss_test.item()),
          "accuracy= {:.4f}".format(acc_test.item()))

    # Convert the predicted outputs to class labels
    _, predicted_labels = output.max(dim=1)

    # Get the true labels
    true_labels = labels[idx_test]

    # Compare predicted and true labels
    num_samples = len(idx_test)
    c=0
    for i in range(num_samples):
        # print("Sample {}: Predicted label = {}, True label = {}".format(i + 1, predicted_labels[idx_test[i]].item(),
        #                                                                 true_labels[i].item()))
        if predicted_labels[idx_test[i]].item() !=  true_labels[i].item():
            c+=1

    print("wrong predictions count:",c)
    return output, loss_test


def accuracy(output, labels):
    preds = output.max(1)[1].type_as(labels)
    correct = preds.eq(labels).double()
    correct = correct.sum()
    return correct / len(labels)


class GCNModel:
    def __init__(self, df, discussionId):
        self.df = df
        self.discussionId = discussionId
        path = 'TensorFiles/discussion_'+str(self.df.loc[self.df['discussion_id'] == self.discussionId, 'discussion_id'].values[0])

        self.adj = torch.load(path + '/adj.pt')
        self.features = torch.load(path + '/features.pt')
        self.labels = torch.load(path + '/labels.pt')
        self.idx_train = torch.load(path + '/idx_train.pt')
        self.idx_val = torch.load(path + '/idx_val.pt')
        self.idx_test = torch.load(path + '/idx_test.pt')

    def runGCN(self):
        # Setting
        seed = 42
        num_epoch = 1700
        lr = 0.01
        weight_decay = 5e-4
        hidden = 16
        dropout = 0.5
        cuda = False

        np.random.seed(seed)
        torch.manual_seed(seed)

        # Create the GCN model and optimizer
        model = GCN(nfeat=self.features.shape[1],
                    nhid=hidden,
                    nclass=self.labels.max().item() + 1,
                    dropout=dropout)
        optimizer = optim.Adam(model.parameters(), lr=lr, weight_decay=weight_decay)

        # Train the model
        train(self.features, self.adj, self.labels, self.idx_train, self.idx_val, model, optimizer, num_epoch)
        output, loss_test = test(self.features, self.adj, self.labels, self.idx_test, model)
