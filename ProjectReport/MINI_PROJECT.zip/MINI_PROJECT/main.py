from LoadGraph import LoadGraph
from LoadFeatures import LoadFeatures
from GCNModel import GCNModel
import pandas as pd

path = 'datasets/convenceme_merged_with_Stance_and_postcount.csv'

discussionId = 28
# read csv file
df = pd.read_csv(path)

# load the graph
ld = LoadGraph(df,discussionId)
ld.loaddata()
ld.postid_DrawGraph()
#

# # cconvert into tensor
ld.totensor_G_post()
#
# # saving tensor files
ld.savePt()

# loading the text of the authors
features = LoadFeatures(df, discussionId)
#
# # preprocessing the text
features.preprocessing()
# # convert them into vectors representation and save as tensor file
features.featureVectors()
# #
GCN = GCNModel(df, discussionId)
GCN.runGCN()

