import pandas as pd
import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
import string
import re
import os
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.preprocessing import normalize
import torch
from nltk.stem import WordNetLemmatizer


class LoadFeatures:
    def __init__(self, df, discussionId):
        self.df = df
        self.discussionId = discussionId
        text = eval(self.df.loc[self.df['discussion_id'] == self.discussionId, 'text'].values[0])
        self.text_features = pd.DataFrame(text, columns=['Text'])
        self.features = ''
        # print(self.text_features)


    # performing preprocessing

    def preprocessing(self):

        # Download the stopwords corpus if not already downloaded
        nltk.download('stopwords')
        nltk.download('punkt')
        nltk.download('wordnet')

        # Set the language for stopwords
        stopwords_language = 'english'

        # Get the list of stopwords for the specified language
        stopwords_list = stopwords.words(stopwords_language)

        # Create an instance of WordNetLemmatizer
        lemmatizer = WordNetLemmatizer()

        # Function to remove stopwords and perform lemmatization on a sentence
        def preprocess_text(sentence):
            # Remove punctuation and digits
            sentence = re.sub(r'[^\w\s]', '', sentence)
            sentence = re.sub(r'\d+', '', sentence)

            # Tokenize the sentence into words
            words = word_tokenize(sentence)

            # Remove stopwords and perform lemmatization
            filtered_words = [lemmatizer.lemmatize(word) for word in words if word.casefold() not in stopwords_list]

            # Join the filtered words back into a sentence
            filtered_sentence = ' '.join(filtered_words)

            return filtered_sentence

        # Apply preprocessing to the 'Text' column
        self.text_features['Text'] = self.text_features['Text'].apply(preprocess_text)
        # print(self.text_features)

    # converting into feature vectors

    def featureVectors(self):
        # Create an instance of TfidfVectorizer
        vectorizer = TfidfVectorizer()

        # Fit the vectorizer to the text data
        vectorizer.fit(self.text_features['Text'])

        # Transform the text data into TF-IDF vectors
        tfidf_vectors = vectorizer.transform(self.text_features['Text'])

        # Normalize the TF-IDF vectors
        normalized_vectors = normalize(tfidf_vectors)

        # Convert the normalized TF-IDF vectors to a dataframe
        df_tfidf = pd.DataFrame(normalized_vectors.toarray(), columns=vectorizer.get_feature_names_out())

        # Print the resulting dataframe
        print(df_tfidf)
        print("Shape : ", df_tfidf.shape)

        # Convert the dataframe to a tensor
        features = torch.tensor(df_tfidf.values)

        # Convert double tensor to float tensor
        self.features = features.float()

        # Print the float tensor
        print(features.shape)


        # # from transformers import BertTokenizer
        # # tokenizer = BertTokenizer.from_pretrained('bert-base-uncased')
        #
        # from transformers import RobertaTokenizer, RobertaModel
        # tokenizer = RobertaTokenizer.from_pretrained('roberta-base')
        # # Tokenize the text column
        # tokenized_texts = self.text_features['Text'].apply(lambda x: tokenizer.tokenize(x))
        #
        # # Convert tokens to input IDs
        # input_ids = tokenized_texts.apply(lambda x: tokenizer.convert_tokens_to_ids(x))
        #
        # # Pad sequences to a fixed length
        # max_length = max(input_ids.apply(len))
        # padded_input_ids = input_ids.apply(lambda x: x + [0] * (max_length - len(x)))
        #
        # # Convert to tensors
        # self.features = torch.tensor(padded_input_ids.tolist())
        # self.features = self.features.float()
        # Print the input tensors
        print("Features:",self.features)
        print(self.features.shape)
        path = 'TensorFiles/discussion_'+str(self.df.loc[self.df['discussion_id'] == self.discussionId, 'discussion_id'].values[0])
        # print(self.df['discussion_id'][39])
        if not os.path.exists(path):z
            os.mkdir(path)
        torch.save(self.features, path+'/features.pt')

